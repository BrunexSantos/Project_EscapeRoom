# define rooms and items
from Light2 import red_green
from tictactoe2 import tictactoe
from Riddle1 import riddle
from Door_sound import door
import pygame
import time

couch = {
    "name": "Couch",
    "type": "furniture",
}

The_Doorway_to_Darkness = {
    "name": "The Doorway to Darkness",
    "type": "door",
}

key_a = {
    "name": "Key for The Doorway to Darkness",
    "type": "key",
    "target": The_Doorway_to_Darkness ,
}

piano = {
    "name": "Piano",
    "type": "furniture",
}

toy_room = {
    "name": "Toy room",
    "type": "room",
}

outside = {
  "name": "Outside"
}
#bed_room1
ghost_room = {
    "name": "Ghost Room",
    "type":"room",
}

table = {
    "name":"Table",
    "type":"furniture",
}

door_b = {
    "name": "The Gateway of Despair",
    "type": "door",
}
door_c = {
    "name": "The Gateway of Doom",
    "type": "door",
}

key_b = {
    "name": "Key for The Gateway of Despair",
    "type": "key",
    "target": door_b,
}

#bed_room2
bathroom = {
    "name": "Bathroom",
    "type":"room",
}

mirror = {
    "name":"Mirror",
    "type":"furniture",
}

corpse = {
    "name":"Corpse",
    "type":"furniture",
}

key_c = {
    "name": "Key for The Gateway of Doom",
    "type": "key",
    "target": door_c,
}
door_d = {
    "name": "The Entrance to the Unknown",
    "type": "door",
}

key_d = {
    "name": "key for The Entrance to the Unknown",
    "type": "key",
    "target": door_d, 
    }

#Living Room
empty_room = {
    "name": "Empty Room",
    "type":"room",
}

wall = {
    "name":"Wall",
    "type":"furniture",
}
chucky = {
    "name":"Chucky",
    "type":"furniture",
}

all_rooms = [toy_room, ghost_room, bathroom, empty_room, outside]

all_doors = [The_Doorway_to_Darkness, door_b,door_c,door_d]

# define which items/rooms are related

object_relations = {
    "Toy room": [couch, piano, The_Doorway_to_Darkness,chucky],
    "Ghost Room": [table, door_b, door_c, The_Doorway_to_Darkness],
    "Table": [key_b],
    "Piano": [key_d],
    "Outside": [door_d],
    "The Doorway to Darkness": [toy_room, ghost_room],
    "The Gateway of Despair": [ghost_room,bathroom],
    "The Gateway of Doom": [ghost_room, empty_room],
    "The Entrance to the Unknown": [empty_room, outside],
    "Mirror":[key_c],
    "Bathroom": [mirror, door_b, corpse],
    "Empty Room":[wall,door_d,door_c],
    "Chucky":[key_a],
}

# define game state. Do not directly change this dict. 
# Instead, when a new game starts, make a copy of this
# dict and use the copy to store gameplay state. This 
# way you can replay the game multiple times.

INIT_GAME_STATE = {
    "current_room": toy_room,
    "keys_collected": [],
    "target_room": outside
}
def piano():
    notes = ["D4", "E4", "A4", "D4"]
    note = input("Enter a 4 letter word (You may have seen it previously) to play using the piano notes (A, B, C, D, E, F, G) or 'done' to stop:").upper()
    if note != 'DEAD':
       play_room(game_state["current_room"])    
    else: 
        if note == "DEAD":
            
            for note in notes: 
                pygame.mixer.init()
                pygame.mixer.music.load(r"C:\Users\Bruno Santos\Desktop\Iron Hack - Semanas\1 Semana\Group Project\python-project\your-code\Red light\Teste Jogo\audio\audio\secret.wav")
                pygame.mixer.music.play() 


def linebreak():
    """
    Print a line break
    """
    print("\n\n")

def start_game():
    """
    Start the game
    """
    print("You wake up on a couch and find yourself in a strange house with no windows which you have never been to before. You don't remember why you are here and what had happened before. You feel some unknown danger is approaching and you must get out of the house, NOW!")
    play_room(game_state["current_room"])

def play_room(room):
    """
    Play a room. First check if the room being played is the target room.
    If it is, the game will end with success. Otherwise, let player either 
    explore (list all items in this room) or examine an item found here.
    """
    game_state["current_room"] = room
    if(game_state["current_room"] == game_state["target_room"]):
        time.sleep(2)
        print("Congrats! You escaped the room!")
        time.sleep(5)
    else:
        print("You are now in " + room["name"])
        intended_action = input("What would you like to do? Type 'explore' or 'examine'?").strip()
        if intended_action == "explore":
            explore_room(room)
            play_room(room)
        elif intended_action == "examine":
            examine_item(input("What would you like to examine?").strip())
        else:
            print("Not sure what you mean. Type 'explore' or 'examine'.")
            play_room(room)
        linebreak()

def explore_room(room):
    """
    Explore a room. List all items belonging to this room.
    """
    items = [i["name"] for i in object_relations[room["name"]]]
    print("You explore the room. This is " + room["name"] + ". You can find " + ", ".join(items))

def get_next_room_of_door(door, current_room):
    """
    From object_relations, find the two rooms connected to the given door.
    Return the room that is not the current_room.
    """
    connected_rooms = object_relations[door["name"]]
    for room in connected_rooms:
        if(not current_room == room):
            return room

def examine_item(item_name):
    """
    Examine an item which can be a door or furniture.
    First make sure the intended item belongs to the current room.
    Then check if the item is a door. Tell player if key hasn't been 
    collected yet. Otherwise ask player if they want to go to the next
    room. If the item is not a door, then check if it contains keys.
    Collect the key if found and update the game state. At the end,
    play either the current or the next room depending on the game state
    to keep playing.
    """
    current_room = game_state["current_room"]
    next_room = ""
    output = None
    
    for item in object_relations[current_room["name"]]:
        if(item["name"] == item_name):
            output = "You examine " + item_name + ". "
            if(item["type"] == "door"):
                have_key = False
                for key in game_state["keys_collected"]:
                    if(key["target"] == item):
                        have_key = True
                if(have_key):
                    door()
                    time.sleep(3)
                    output += "You unlock it with a key you have."
                    next_room = get_next_room_of_door(item, current_room)
                else:
                    output += "It is locked but you don't have the key."
            else:
                if(item["name"] in object_relations and len(object_relations[item["name"]])>0):
                    if(item["name"] == "Piano"):
                        piano()
                        item_found = object_relations[item["name"]].pop()
                        game_state["keys_collected"].append(item_found)
                        output += "You find " + item_found["name"] + "."
                    elif (item["name"] == "Mirror"):
                        red_green()
                        item_found = object_relations[item["name"]].pop()
                        game_state["keys_collected"].append(item_found)
                        output += "You find " + item_found["name"] + "."
                    elif (item["name"] == "Table"):
                        tictactoe()
                        item_found = object_relations[item["name"]].pop()
                        game_state["keys_collected"].append(item_found)
                        output += "You find " + item_found["name"] + "."
                    else:
                        item_found = object_relations[item["name"]].pop()
                        game_state["keys_collected"].append(item_found)
                        output += "You find " + item_found["name"] + "."
                elif (item["name"] == "Wall"):
                    riddle()
                else:
                    output += "There isn't anything interesting about it."
            print(output)
            break

    if(output is None):
        print("The item you requested is not found in the current room.")
    
    if(next_room and input("Are you sure you want to go to the next room? You do not know what is waiting for you. Enter 'yes' or 'no'").strip() == 'yes'):
        play_room(next_room)
    else:
        play_room(current_room)
game_state = INIT_GAME_STATE.copy()

start_game()