import time
def riddle():
    print("You look at the wall and it appears writting in it. The words are written in blood!")
    time.sleep(1)
    print("It appears to be a riddle! In order to solve it you need to awnser with your own blood!")
    time.sleep(1)
    print("I am often found in a grave, but I am not alive.")
    time.sleep(1)
    print("I can be mourned, but I will never cry.")
    time.sleep(1)
    print("I am always present at funerals, but never attend them.")
    time.sleep(1)
    print("What am I?")

    answer = input("Type answer")
    answer2 = answer.lower()
    if answer2 != "dead":
        print("Wrong answer, try again!")
        riddle()
    else:
        print("Yes! The answer is \033[1mDead\033[0m")

    return "You got it right, you get the key!"
