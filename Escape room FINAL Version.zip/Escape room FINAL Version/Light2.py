import time
import random
from colorama import init, Fore, Style

def red_green():
    init()
    print(Fore.GREEN +"You enter the next room and see a mirror the mirror is colored green"+ Style.RESET_ALL)
    time.sleep(2)
    print('\033[32m' +"You can see the next key inside the mirror.")
    time.sleep(2)
    steps = input("How many steps does it take to get to the key?")
    time.sleep(2)
    print( '\033[31m'+"You have taken" + " ", steps," steps " + "the mirror turned bloody red and you no longer can see the key."+ '\033[0m')
    time.sleep(2)
    print('\033[32m' +"You have to take the necessary amount of steps so that the mirror does not turn red so that you can get the key."+'\033[0m')
    print('\033[32m' +"You can start in 10 seconds"+'\033[0m')
    time.sleep(2)
    timer()
    take_steps()
    return "You got the key!"
def take_steps():
        steps2 = int(input("How many steps do you want to take?"))
        random_steps = random.randint(1, 2)
        random_steps2 = random.randint(1, 2)
        if steps2>=1 and steps2<=2:
            if steps2 == random_steps:
                print('\033[32m' +"The mirror turned green you may take another step."+'\033[0m')
                steps3 = int(input("Take more steps to get to key!"))
                if steps3 == random_steps2:
                    print('\033[32m' +"You reached the mirror! You get the key!"+'\033[0m')
                else:
                    print('\033[31m'+"The mirror turned red! Start again."+ '\033[0m')
                    take_steps()
            else:
                print('\033[31m'+"The mirror turned red! Start again."+ '\033[0m')
                take_steps()
        else:
             print('\033[31m'+"The steps you took were not beetween 1 and 2 the mirror turned red. Start Over."+ '\033[0m')
             take_steps()
        return
def timer():
    timer = 10
    while timer > 0:
        print("Time until start:", timer, "seconds")
        time.sleep(1)
        timer -= 1
    return 
    
