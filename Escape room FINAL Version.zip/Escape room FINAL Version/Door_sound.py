import pygame 
def door():
    pygame.mixer.init()
    pygame.mixer.music.load(r"C:\Users\Bruno Santos\Desktop\Iron Hack - Semanas\1 Semana\Group Project\python-project\your-code\Red light\Teste Jogo\Escape room FINAL Version\HORROR DOOR OPENING SOUND EFFECT . soundeffects.mp3")
    pygame.mixer.music.play()
    return
